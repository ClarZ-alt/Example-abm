package modelo;
public class Propuesta {
	private String origen;
	private String  categoria;
	private String  autor;
	private int fecha;
	private String titulo;
	private String descripcion;
	private String motivacion;
	private String estado;
	private static String estadoPendiente = "pendiente" ;
    public  String estadoAceptada= " aceptada";
	public  String estadoRechazada="rechazada" ;
	private String  motivo;
	
	//prueba lab
	
	public static String getEstadoPendiente() {
		return estadoPendiente;
	}
	public static void setEstadoPendiente(String estadoPendiente) {
		Propuesta.estadoPendiente = estadoPendiente;
	}
	
	
	
	
	public Propuesta() {
	}
	public Propuesta(String origen, String autor, int fecha, String titulo, String descripcion, String motivacion) {
		super();
		this.origen = origen;
		this.autor = autor;
		this.fecha = fecha;
		this.titulo = titulo;
		this.descripcion = descripcion;
		this.motivacion = motivacion;
	}
	public Propuesta(String origen, String autor, int fecha, String titulo, String descripcion, String motivacion,
			String categoria) {
		super();
		this.origen = origen;
		this.autor = autor;
		this.fecha = fecha;
		this.titulo = titulo;
		this.descripcion = descripcion;
		this.motivacion = motivacion;
		this.categoria = categoria;
	}
		// TODO Auto-generated constructor stub
	
	public Propuesta(String origen, String autor, int fecha, String titulo, String descripcion, String motivacion,
			String categoria, String estado) {
		// TODO Auto-generated constructor stub
		super();
		this.origen = origen;
		this.autor = autor;
		this.fecha = fecha;
		this.titulo = titulo;
		this.descripcion = descripcion;
		this.motivacion = motivacion;
		this.categoria = categoria;
		this.estado= estado;
	}
	public String getOrigen() {
		return origen;
	}
	public void setOrigen(String origen) {
		this.origen = origen;
	}
	public String getCategoria() {
		return categoria;
	}
	public void setCategoria(String categoria) {
		this.categoria = categoria;
	}
	public String getAutor() {
		return autor;
	}
	public void setAutor(String autor) {
		this.autor = autor;
	}
	public int getFecha() {
		return fecha;
	}
	public void setFecha(int fecha) {
		this.fecha = fecha;
	}
	public String getTitulo() {
		return titulo;
	}
	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}
	public String getDescripcion() {
		return descripcion;
	}
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
	public String getMotivacion() {
		return motivacion;
	}
	public void setMotivacion(String motivacion) {
		this.motivacion = motivacion;
	}
	public String getEstado() {
		return estado;
	}
	public void setEstado(String estado) {
		this.estado = estado;
	}
	public String getMotivo() {
		return motivo;
	}
	public void setMotivo(String motivo) {
		this.motivo = motivo;
	}
	
	
	
}