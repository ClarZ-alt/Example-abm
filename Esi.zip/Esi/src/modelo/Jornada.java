package modelo;
public class Jornada {
	
	private String objetivoPedagogico;
	private String referenteInstitucional;
	private String objetivo;
	private String titulo;
	
	public Jornada(String titulo, String objetivoPedagogico, String referenteInstitucional, String objetivo) {
		super();

		this.titulo = titulo;
		this.objetivoPedagogico = objetivoPedagogico;
		this.referenteInstitucional = referenteInstitucional;
		this.objetivo = objetivo;
	}
	
	
	public String getObjetivoPedagogico() {
		return objetivoPedagogico;
	}
	public void setObjetivoPedagogico(String objetivoPedagogico) {
		this.objetivoPedagogico = objetivoPedagogico;
	}
	public String getReferenteInstitucional() {
		return referenteInstitucional;
	}
	public void setReferenteInstitucional(String referenteInstitucional) {
		this.referenteInstitucional = referenteInstitucional;
	}
	public String getObjetivo() {
		return objetivo;
	}
	public void setObjetivo(String objetivo) {
		this.objetivo = objetivo;
	}
	public String getTitulo() {
		return titulo;
	}
	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}
}
