	package modelo;

import java.util.ArrayList;

public abstract class Material  {
	private String titulo;
	private String categoria;
	private String descripcion;
	private String fuente;
	private String enlace;
	
	
	public Material(String titulo,  String descripcion,String categoria, String fuente, String enlace) {
		this.titulo = titulo;
		this.descripcion = descripcion;
		this.categoria = categoria;
		this.fuente = fuente;
		this.enlace = enlace;
	}
	
	
	public String getTitulo() {
		return titulo;
	}
	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}
	public String getCategoria() {
		return categoria;
	}
	public void setCategoria(String categoria) {
		this.categoria = categoria;
	}
	public String getDescripcion() {
		return descripcion;
	}
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
	public String getFuente() {
		return fuente;
	}
	public void setFuente(String fuente) {
		this.fuente = fuente;
	}
	public String getEnlace() {
		return enlace;
	}
	public void setEnlace(String enlace) {
		this.enlace = enlace;
	}
	
	public abstract boolean esPrioritario();
}
