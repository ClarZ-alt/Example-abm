package app;

import javax.swing.JFrame;

import vista.MenuPrincipal;


public class app {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		JFrame marco = new JFrame();
		marco.setBounds(500, 250, 1100, 600);
		marco.setVisible(true);
		marco.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		marco.setContentPane(new MenuPrincipal() );
		marco.validate();
	}
}
