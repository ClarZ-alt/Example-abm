package vista;

import java.util.ArrayList;




import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

import dao.CategoriaDAO;
import dao.JornadaDAO;
import modelo.Jornada;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class JornadaAltaEdicionPanel extends JPanel {
	private ArrayList<Jornada> jornadas;
	private JTextField txtTitulo;
	private JTextField txtReferenInstitu;
	private JTextField txtObjetivo;
	private Jornada jornada;
	private JComboBox<String> comboBox;
	

	/**
	 * Create the panel.
	 */
	public JornadaAltaEdicionPanel() {
		setLayout(null);

		JLabel lblNewLabel = new JLabel("Jornada");
		lblNewLabel.setBounds(81, 11, 49, 31);
		add(lblNewLabel);

		JLabel lblNewLabel_1 = new JLabel("Titulo");
		lblNewLabel_1.setBounds(35, 47, 77, 14);
		add(lblNewLabel_1);

		JLabel lblNewLabel_2 = new JLabel("Categoria");
		lblNewLabel_2.setBounds(35, 72, 77, 14);
		add(lblNewLabel_2);

		JLabel lblNewLabel_3 = new JLabel("Referente Institucional");
		lblNewLabel_3.setBounds(35, 97, 77, 14);
		add(lblNewLabel_3);

		JLabel lblNewLabel_4 = new JLabel("Objetivo");
		lblNewLabel_4.setBounds(35, 122, 77, 14);
		add(lblNewLabel_4);

		txtTitulo = new JTextField();
		txtTitulo.setBounds(122, 44, 86, 20);
		add(txtTitulo);
		txtTitulo.setColumns(10);
/*
 * 
 * 
	private JTextField txtObjePedago;
		txtObjePedago = new JTextField();
		txtObjePedago.setBounds(122, 69, 86, 20);
		add(txtObjePedago);
		txtObjePedago.setColumns(10);
*/
		txtReferenInstitu = new JTextField();
		txtReferenInstitu.setBounds(122, 94, 86, 20);
		add(txtReferenInstitu);
		txtReferenInstitu.setColumns(10);

		txtObjetivo = new JTextField();
		txtObjetivo.setBounds(122, 119, 86, 20);
		add(txtObjetivo);
		txtObjetivo.setColumns(10);

		//
		comboBox = new JComboBox<String>();
		comboBox.setBounds(122, 68, 86, 22);
		add(comboBox);
		
		CategoriaDAO cDao = new CategoriaDAO();
		ArrayList<String> categorias = cDao.traerTodas();
		comboBox.addItem("selecione categoria");
		for (String c : categorias) {
			
			comboBox.addItem(c);
		}
		//
		
		JButton btnNewButton = new JButton("Guardar");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				
				String titulo = txtTitulo.getText();
				String objePedagogico = comboBox.getSelectedItem().toString();
				String referenInstitu = txtReferenInstitu.getText();
				String objetivo = txtObjetivo.getText();
				JornadaDAO eDao = new JornadaDAO();
				
				if (esEdicion()) {
					// Es una modificación
					Jornada nuevo = new Jornada(titulo, objePedagogico, referenInstitu,objetivo);
					eDao.modificar(nuevo, jornada.getTitulo());
				} else {
					// Es un alta
					Jornada jornada = new Jornada(titulo, objePedagogico, referenInstitu,objetivo);
					
					eDao.guardar(jornada);
				}
				JFrame marco = 
						(JFrame) SwingUtilities.getWindowAncestor((JComponent) ae.getSource());
				marco.setContentPane(new MenuPrincipal());
				marco.validate();
			}
		});
		btnNewButton.setBounds(119, 173, 89, 23);
		add(btnNewButton);
	}
	public JornadaAltaEdicionPanel(Jornada e) {
		// Ejecuto primero el constructor sin argumentos para que se contruya la pantalla.
		this();
		// Cargo los datos del objeto estudiante en los campos de texto.
		txtTitulo.setText(e.getTitulo());
		comboBox.setSelectedItem(e.getObjetivoPedagogico());
		txtReferenInstitu.setText(e.getReferenteInstitucional());
		txtObjetivo.setText(e.getObjetivo());
		this.jornada = e;
		
	}
	
	public boolean esEdicion() {
		return this.jornada != null;
		
	}
}