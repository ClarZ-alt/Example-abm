package vista;

import java.awt.event.ActionEvent;

import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.SwingUtilities;
import javax.swing.table.DefaultTableModel;

import dao.PropuestaDAO;
import modelo.Material;
import modelo.Propuesta;

public class PropuestasAprobadas extends JPanel{
private JTable table;
	
	private ArrayList<Propuesta> propuestas;
	/**
	 * Create the panel.
	 * @param m 
	 * @param m 
	 */
	public PropuestasAprobadas(Material obtenerSelecionado) {
		setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(36, 76, 450, 250);
		add(scrollPane);
		
		table = new JTable();
		DefaultTableModel dataModel = new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
					"Origen", "Categoria", "Titulo" , "Estado"}
		);
		table.setModel(dataModel);
		scrollPane.setViewportView(table);
		
		
		JButton btnNewButton = new JButton("Volver");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				JFrame marco = 
						(JFrame) SwingUtilities.getWindowAncestor((JComponent) e.getSource());
				marco.setContentPane(new MaterialPanel());
				marco.validate();
				
			}
		});
		btnNewButton.setBounds(38, 360, 89, 23);
		add(btnNewButton);
		

		cargarTabla(dataModel,obtenerSelecionado );

		
	}
	public PropuestasAprobadas() {
		// TODO Auto-generated constructor stub
	}
	public String extraerVar(Material m ) {
		
		return m.getCategoria();
	}
	
	private void cargarTabla(DefaultTableModel dataModel, Material m) {
		
		dataModel.setRowCount(0);
		PropuestaDAO pDao = new PropuestaDAO();
		propuestas = pDao.traerPropuestasPorCategoria(extraerVar(m));
		for (Propuesta p : propuestas) {
			Object[] fila = new Object[] { p.getOrigen(), p.getCategoria(), p.getTitulo() , p.getEstado()};
			dataModel.addRow(fila);
		}
		}
}