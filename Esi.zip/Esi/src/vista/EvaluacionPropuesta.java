package vista;

import java.awt.Dimension;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.SwingUtilities;
import javax.swing.table.DefaultTableModel;

import dao.PropuestaDAO;
import modelo.Propuesta;

public class EvaluacionPropuesta extends JPanel{
	
	private JTable table;
	private ArrayList<Propuesta> propuestas;
	JLabel  lblorigen, lblcategoria, lblautor, lblfecha, lbltitulo, lbldescripcion, lblmotivacion;
	private Propuesta propuesta;
/**
 * Create the panel.
 */
 public EvaluacionPropuesta() {
	
	setLayout(null);
	
	JScrollPane scrollPane = new JScrollPane();
	scrollPane.setBounds(470, 82, 400, 312);
	add(scrollPane);

	table = new JTable();
	DefaultTableModel dataModel = new DefaultTableModel(new Object[][] {},
			new String[] { "Origen", "Categoria", "Titulo" , "Estado"});
	table.setModel(dataModel);
	scrollPane.setViewportView(table);
	
	JButton btnNewButton_5 = new JButton("Detalles");
	btnNewButton_5.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {

			JFrame marco = 
					(JFrame) SwingUtilities.getWindowAncestor((JComponent) e.getSource());
			marco.setContentPane(new EvaluacionPropuesta(obtenerSeleccionado()));
			marco.validate();
			
		}
	});
	btnNewButton_5.setBounds(584, 405, 200, 23);
	add(btnNewButton_5);
	
	
	JLabel lblOrigen = new JLabel("Origen: ");
	lblOrigen.setBounds(74, 110, 65, 31);
	add(lblOrigen);

	JLabel lblAutor = new JLabel("Autor:");
	lblAutor.setBounds(74, 234, 65, 31);
	add(lblAutor);

	JLabel lblFecha = new JLabel("Fecha:");
	lblFecha.setBounds(74, 151, 65, 31);
	add(lblFecha);

	JLabel lblTitulo = new JLabel("Titulo: ");
	lblTitulo.setBounds(74, 279, 65, 31);
	add(lblTitulo);
	
	JLabel lblDescripcion = new JLabel("Descripcion:");
	lblDescripcion.setBounds(74, 321, 93, 31);
	add(lblDescripcion);
	
	JLabel lblMotivacion = new JLabel("Motivacion:");
	lblMotivacion.setBounds(74, 363, 93, 31);
	add(lblMotivacion);

	JLabel lblCategoria = new JLabel("Categoria:");
	lblCategoria.setBounds(74, 193, 65, 31);
	add(lblCategoria);
	lblorigen = new JLabel("_");
	lblorigen.setBounds(219, 110, 108, 31);
	add(lblorigen);

	lblautor = new JLabel("_");
	lblautor.setBounds(219, 234, 108, 31);
	add(lblautor);
	
	lblfecha = new JLabel("_");
	lblfecha.setBounds(219, 152, 108, 31);
	add(lblfecha);
	
	lbltitulo = new JLabel("_");
	lbltitulo.setBounds(219, 279, 108, 31);
	add(lbltitulo);
	
	lbldescripcion = new JLabel("_");
	lbldescripcion.setBounds(219, 321, 108, 31);
	add(lbldescripcion);
	
	lblmotivacion = new JLabel("_");
	lblmotivacion.setBounds(219, 363, 108, 31);
	add(lblmotivacion);

	lblcategoria = new JLabel("_");
	lblcategoria.setBounds(219, 193, 108, 31);
	add(lblcategoria);
	
	JButton btnAceptar = new JButton("Aceptar");
	btnAceptar.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			String estado = "Aprobado";
			propuesta = new Propuesta( propuesta.getOrigen(),propuesta.getCategoria(),propuesta.getFecha(), propuesta.getTitulo(), propuesta.getDescripcion(), propuesta.getMotivacion(), estado );
			PropuestaDAO pDAO= new PropuestaDAO();
			pDAO.modificarEstado(estado,propuesta.getTitulo());
			JFrame marco = 
					(JFrame) SwingUtilities.getWindowAncestor((JComponent) e.getSource());
			marco.setContentPane(new PropuestaPanel());
			marco.validate();
		}
	});
	
	btnAceptar.setBounds(195, 504, 89, 23);
	add(btnAceptar);
	
	JButton btnRechazar = new JButton("Rechazar\r\n");
	btnRechazar.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			String estado = "Rechazado";
			propuesta = new Propuesta( propuesta.getOrigen(),propuesta.getCategoria(),propuesta.getFecha(), propuesta.getTitulo(), propuesta.getDescripcion(), propuesta.getMotivacion(), estado );
			PropuestaDAO pDAO= new PropuestaDAO();
			pDAO.modificarEstado(estado,propuesta.getTitulo());
   			 JFrame marco =
   					 (JFrame) SwingUtilities.getWindowAncestor((JComponent) e.getSource());
   			 marco.setContentPane(new PropuestaPanel());
   			 marco.validate();

		}
	});
	btnRechazar.setBounds(318, 504, 89, 23);
	add(btnRechazar);
	
	JButton btnNewButton_4 = new JButton("Volver");
	btnNewButton_4.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {

			JFrame marco = 
					(JFrame) SwingUtilities.getWindowAncestor((JComponent) e.getSource());
			marco.setContentPane(new MenuPrincipal());
			marco.validate();		
		}
	});
	btnNewButton_4.setBounds(35, 504, 89, 23);
	add(btnNewButton_4);
	
	cargarTabla(dataModel);
}
	

public EvaluacionPropuesta(Propuesta p) {
	this();
	
	lblorigen.setText(""+p.getOrigen());
	lblautor.setText(""+p.getAutor());
	lblfecha.setText(""+p.getFecha());
	lbltitulo.setText(""+p.getTitulo());
	lbldescripcion.setText(""+p.getDescripcion());
	lblmotivacion.setText(""+p.getMotivacion());
	lblcategoria.setText(""+p.getCategoria());
	this.propuesta = p;
}

	
	private void cargarTabla(DefaultTableModel dataModel) {
		dataModel.setRowCount(0);
		PropuestaDAO pDao = new PropuestaDAO();
		propuestas = pDao.traerPendientes();
		for (Propuesta p : propuestas) {
			Object[] fila = new Object[] { p.getOrigen(), p.getCategoria(), p.getTitulo() , p.getEstado()};
			dataModel.addRow(fila);
		} }
	
	
	
	private Propuesta obtenerSeleccionado() {
		int filaSeleccionada = table.getSelectedRow();
		return propuestas.get(filaSeleccionada);
	}
	
}	



