package vista;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;
import javax.swing.table.DefaultTableModel;
import dao.PropuestaDAO;
import modelo.Propuesta;
import javax.swing.JScrollPane;
import javax.swing.JTable;

public class PropuestaPanel extends JPanel {
	private JTable table;
	private ArrayList<Propuesta> propuestas;

	public PropuestaPanel() {
		// TODO Auto-generated constructor stub
		setLayout(null);

		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(36, 76, 236, 159);
		add(scrollPane);

		table = new JTable();
		DefaultTableModel dataModel = new DefaultTableModel(new Object[][] {},
				new String[] { "Origen", "Categoria", "Titulo" , "Estado"});
		table.setModel(dataModel);
		scrollPane.setViewportView(table);
		cargarTabla(dataModel);
		
		JButton btnNewButton = new JButton("crear");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JFrame marco = (JFrame) SwingUtilities.getWindowAncestor((JComponent) e.getSource());
				marco.setContentPane(new PropuestaAltaEdicionPanel());
				marco.validate();

			}
		});
		JLabel lblNewLabel = new JLabel("Propuesta");
		lblNewLabel.setBounds(37, 11, 90, 14);
		add(lblNewLabel);

		btnNewButton.setBounds(352, 88, 57, 23);
		add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("eliminar");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Propuesta p = obtenerSeleccionado();
				PropuestaDAO pDao = new PropuestaDAO();
				pDao.eliminar(p.getTitulo());
			}
		});
		btnNewButton_1.setBounds(352, 156, 69, 23);
		add(btnNewButton_1);
		
		JButton btnNewButton_3 = new JButton("modificar");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JFrame marco = (JFrame) SwingUtilities.getWindowAncestor((JComponent) e.getSource());
				marco.setContentPane(new PropuestaAltaEdicionPanel(obtenerSeleccionado()));
				marco.validate();
				cargarTabla(dataModel);
			}
		});
		btnNewButton_3.setBounds(352, 122, 88, 23);
		add(btnNewButton_3);

		JButton btnNewButton_4 = new JButton("Volver");
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				JFrame marco = 
						(JFrame) SwingUtilities.getWindowAncestor((JComponent) e.getSource());
				marco.setContentPane(new MenuPrincipal());
				marco.validate();
				
			}
		});
		btnNewButton_4.setBounds(38, 266, 89, 23);
		add(btnNewButton_4);

		JButton btnNewButton_5 = new JButton("Evaluar Propuestas Pendientes");
		btnNewButton_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				JFrame marco = 
						(JFrame) SwingUtilities.getWindowAncestor((JComponent) e.getSource());
				marco.setContentPane(new EvaluacionPropuesta());
				marco.validate();
				
			}
		});
		btnNewButton_5.setBounds(183, 266, 200, 23);
		add(btnNewButton_5);
		
		
		cargarTabla(dataModel);
	}

	private void cargarTabla(DefaultTableModel dataModel) {
		dataModel.setRowCount(0);
		PropuestaDAO pDao = new PropuestaDAO();
		propuestas = pDao.traerTodes();
		for (Propuesta p : propuestas) {
			Object[] fila = new Object[] { p.getOrigen(), p.getCategoria(), p.getTitulo() , p.getEstado()};
			dataModel.addRow(fila);
		}
	}

	public PropuestaPanel(Propuesta e) {
		this();

	}

	private Propuesta obtenerSeleccionado() {
		int filaSeleccionada = table.getSelectedRow();
		return propuestas.get(filaSeleccionada);
	}
}