package vista;

import java.util.ArrayList;


import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

import dao.CategoriaDAO;
import dao.PropuestaDAO;
import modelo.Propuesta;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JComboBox;

public class PropuestaAltaEdicionPanel extends JPanel {
	private JTextField textorigen;
	private JTextField textautor;
	private JTextField textfecha;
	private JTextField texttitulo;
	private JTextField textmotivo;
	private JTextField textdescripcion;
	private JTextField textestado;
	private JTextField textmotivacion;
	private JComboBox<String> comboBox;
	private Propuesta propuesta;
	private JButton btnNewButton;
	private JLabel lblNewLabel_8;
private JButton btnNewButton_1;
	/**
	 * Create the panel.
	 */
	public PropuestaAltaEdicionPanel() {
		setLayout(null);

		JLabel lblNewLabel = new JLabel("Propuesta");
		lblNewLabel.setBounds(81, 11, 49, 31);
		add(lblNewLabel);

		JLabel lblNewLabel_1 = new JLabel("origen");
		lblNewLabel_1.setBounds(35, 47, 46, 14);
		add(lblNewLabel_1);

		JLabel lblNewLabel_2 = new JLabel("categoria");
		lblNewLabel_2.setBounds(35, 72, 46, 14);
		add(lblNewLabel_2);

		JLabel lblNewLabel_3 = new JLabel("autor");
		lblNewLabel_3.setBounds(35, 97, 46, 14);
		add(lblNewLabel_3);

		JLabel lblNewLabel_4 = new JLabel("fecha");
		lblNewLabel_4.setBounds(35, 122, 46, 14);
		add(lblNewLabel_4);
		
		JLabel lblNewLabel_5 = new JLabel("titulo");
		lblNewLabel_5.setBounds(35, 150, 46, 14);
		add(lblNewLabel_5);

		JLabel lblNewLabel_6 = new JLabel("descripcion");
		lblNewLabel_6.setBounds(35, 175, 61, 14);
		add(lblNewLabel_6);

		JLabel lblNewLabel_7 = new JLabel("motivacion");
		lblNewLabel_7.setBounds(35, 195, 61, 14);
		add(lblNewLabel_7);

		textorigen = new JTextField();
		textorigen.setBounds(122, 44, 86, 20);
		add(textorigen);
		textorigen.setColumns(10);

		textautor = new JTextField();
		textautor.setBounds(122, 94, 86, 20);
		add(textautor);
		textautor.setColumns(10);

		textfecha = new JTextField();
		textfecha.setBounds(122, 119, 86, 20);
		add(textfecha);
		textfecha.setColumns(10);

		texttitulo = new JTextField();
		texttitulo.setBounds(122, 147, 86, 20);
		add(texttitulo);
		texttitulo.setColumns(10);
		
		textdescripcion = new JTextField();
		textdescripcion.setColumns(10);
		textdescripcion.setBounds(122, 172, 86, 20);
		add(textdescripcion);

		textmotivacion = new JTextField();
		textmotivacion.setColumns(10);
		textmotivacion.setBounds(122, 192, 86, 20);
		add(textmotivacion);

		
		comboBox = new JComboBox<String>();
		comboBox.setBounds(122, 68, 86, 22);
		add(comboBox);
		
		CategoriaDAO cDao = new CategoriaDAO();
		ArrayList<String> categorias = cDao.traerTodas();
		comboBox.addItem("selecione categoria");
		for (String c : categorias) {
			
			comboBox.addItem(c);
		}
		
		
		JButton btnNewButton_2 = new JButton("Guardar");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				 String origen= textorigen.getText();
				 String autor = textautor.getText();
				 String categoria= comboBox.getSelectedItem().toString();
				 int fecha= Integer.valueOf(textfecha.getText());
				 String titulo = texttitulo.getText();
				 String descripcion= textdescripcion.getText();
				 String motivacion=textmotivacion.getText();
				// String motivo= textmotivo.getText();
				 
				 Propuesta p = new Propuesta(origen, autor, fecha, titulo, descripcion, motivacion, categoria);
				 p.setEstado(p.getEstadoPendiente());
				 
				 PropuestaDAO pDao = new PropuestaDAO();
				 if (esEdicion()) {
					 Propuesta propuestaModificada = new Propuesta(origen, autor, fecha, titulo, descripcion, motivacion, categoria);
					propuestaModificada.setEstado(propuesta.getEstado());
					
					try {
					propuestaModificada.setMotivo(textmotivo.getText());
					}
					catch (Exception ae) {
						// TODO: handle exception
					}
					
					pDao.modificar(propuesta.getTitulo(), propuestaModificada);
				} else {
					Propuesta propuesta= new Propuesta(origen, autor, fecha, titulo, descripcion, motivacion, categoria);
					propuesta.setEstado(propuesta.getEstadoPendiente());
					
					pDao.guardar(propuesta);

				}
				 
				JFrame marco = 
						(JFrame) SwingUtilities.getWindowAncestor((JComponent) e.getSource());
				marco.setContentPane(new PropuestaPanel());
				marco.validate();
			}
		});
		
		btnNewButton_2.setBounds(35, 266, 89, 23);
		add(btnNewButton_2);
		
		
		
	}
	public PropuestaAltaEdicionPanel(Propuesta e) {
		this();
		textorigen.setText(""+e.getOrigen());
		textautor.setText(""+e.getAutor());
		textfecha.setText(""+e.getFecha());
		texttitulo.setText(""+e.getTitulo());
		textdescripcion.setText(""+e.getDescripcion());
		textmotivacion.setText(""+e.getMotivacion());
		comboBox.setSelectedItem(""+e.getCategoria());
		
		this.propuesta = e;
		/*btnNewButton = new JButton("Aceptar");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				propuesta.setEstado(propuesta.getEstadoAceptada());
				
			}
		});
		btnNewButton.setBounds(280, 68, 89, 23);
		add(btnNewButton);
		btnNewButton_1 = new JButton("Rechazar");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				textmotivo = new JTextField();
				textmotivo.setColumns(10);
				textmotivo.setBounds(122, 239, 86, 20);
				add(textmotivo);
				
				lblNewLabel_8 = new JLabel("motivo");
				lblNewLabel_8.setBounds(35, 239, 61, 14);
				add(lblNewLabel_8);
				repaint();
				propuesta.setEstado(propuesta.getEstadoRechazada());
				
				//propuesta.setMotivo(textmotivo.getText());
			}
		});
		btnNewButton_1.setBounds(280, 118, 89, 23);
		add(btnNewButton_1);*/
	}
	public boolean esEdicion() {
		return this.propuesta!= null;
		
	}
}

