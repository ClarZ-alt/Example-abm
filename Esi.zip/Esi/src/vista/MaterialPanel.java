package vista;

import javax.swing.JPanel;



import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.SwingUtilities;
import javax.swing.table.DefaultTableModel;

import dao.MaterialDAO;
import dao.PropuestaDAO;
import modelo.Material;
import modelo.Propuesta;

import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JFrame;

import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.awt.event.ActionEvent;

public class MaterialPanel extends JPanel {
	private JTable table;

	private ArrayList<Material> materiales;
	
	public MaterialPanel() {
		setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Material");
		lblNewLabel.setBounds(37, 23, 46, 14);
		add(lblNewLabel);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(37, 48, 236, 159);
		add(scrollPane);

		table = new JTable();
		DefaultTableModel dataModel = new DefaultTableModel(new Object[][] {},
				new String[] { "Titulo", "Descripcion", "Categoria","Fuente", "Enlace" });
		table.setModel(dataModel);
		scrollPane.setViewportView(table);
		
		JButton btnNewButton = new JButton("crear");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JFrame marco = 
						(JFrame) SwingUtilities.getWindowAncestor((JComponent) e.getSource());
				marco.setContentPane(new MaterialAltaEdicionPanel());
				marco.validate();
			}
		});
		btnNewButton.setBounds(314, 44, 89, 23);
		add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("modificar");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JFrame marco = (JFrame) SwingUtilities.getWindowAncestor((JComponent) e.getSource());
				marco.setContentPane(new MaterialAltaEdicionPanel(obtenerSeleccionado()));
				marco.validate();
				cargarTabla(dataModel);
			}
		});
		btnNewButton_1.setBounds(314, 89, 89, 23);
		add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("eliminar");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Material m = obtenerSeleccionado();
				MaterialDAO pDao = new MaterialDAO();
				pDao.eliminar(m.getTitulo());
			}
		});
		btnNewButton_2.setBounds(314, 133, 89, 23);
		add(btnNewButton_2);
		
		JButton btnNewButton_3 = new JButton("Volver");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				JFrame marco = 
						(JFrame) SwingUtilities.getWindowAncestor((JComponent) e.getSource());
				marco.setContentPane(new MenuPrincipal());
				marco.validate();
				
			}
		});
		btnNewButton_3.setBounds(38, 266, 89, 23);
		add(btnNewButton_3);
		
		JButton btnNewButton_4 = new JButton("Ver Detalles");
		btnNewButton_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				JFrame marco = 
						(JFrame) SwingUtilities.getWindowAncestor((JComponent) e.getSource());
				marco.setContentPane(new PropuestasAprobadas(obtenerSeleccionado()));
				marco.validate();
				
			}
		});
		btnNewButton_4.setBounds(314, 184, 89, 23);
		add(btnNewButton_4);
		
		cargarTabla(dataModel);
		
	}
	private void cargarTabla(DefaultTableModel dataModel) {
		dataModel.setRowCount(0);
		MaterialDAO eDao = new MaterialDAO();
		materiales = eDao.traerTodas();
		for (Material e : materiales) {
			Object[] fila = new Object[] {e.getTitulo(), e.getDescripcion(), e.getCategoria(), e.getFuente(),e.getEnlace()};
			dataModel.addRow(fila);
		}}
		public MaterialPanel(Material e) {
			this();

		}

		private Material obtenerSeleccionado() {
			int filaSeleccionada = table.getSelectedRow();
			return materiales.get(filaSeleccionada);
		}
}