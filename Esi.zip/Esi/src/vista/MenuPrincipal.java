package vista;

import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.swing.table.DefaultTableModel;

import dao.JornadaDAO;
import modelo.Jornada;

import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.awt.event.ActionEvent;

public class MenuPrincipal extends JPanel {

	private JTable table;
	private ArrayList<Jornada> jornadas;
	/**
	 * Create the panel.
	 */
	public MenuPrincipal() {
		setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Jornadas");
		lblNewLabel.setBounds(37, 23, 94, 14);
		add(lblNewLabel);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(36, 76, 450, 250);
		add(scrollPane);
		
		table = new JTable();
		DefaultTableModel dataModel = new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"Titulo", "Categoria", "Referente Institucional", "Objetivo"}
		);
		table.setModel(dataModel);
		scrollPane.setViewportView(table);
		
		JButton btnCrear= new JButton("Crear");
		btnCrear.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				JFrame marco = 
						(JFrame) SwingUtilities.getWindowAncestor((JComponent) ae.getSource());
				marco.setContentPane(new JornadaAltaEdicionPanel());
				marco.validate();
			}
		});
		btnCrear.setBounds(500, 73, 89, 23);
		add(btnCrear);
		
		JButton btnEliminar = new JButton("Eliminar");
		btnEliminar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae){
				Jornada e = obtenerJornadaSeleccionada();
				JornadaDAO eDao = new JornadaDAO();
				eDao.eliminar(e.getTitulo());
				cargarTabla(dataModel); 
			}
		});
		btnEliminar.setBounds(500, 107, 89, 23);
		add(btnEliminar);
		
		JButton btnModificar = new JButton("Modificar");
		btnModificar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JFrame marco = (JFrame) SwingUtilities.getWindowAncestor((JComponent) e.getSource());
				marco.setContentPane(new JornadaAltaEdicionPanel(obtenerJornadaSeleccionada()));
				marco.validate();
				cargarTabla(dataModel);
			}
		});
		btnModificar.setBounds(500, 144, 89, 23);
		add(btnModificar);

		JButton btnVerMateriales= new JButton("Ver Materiales de Jornada");
		btnVerMateriales.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent m) {
				JFrame marco = (JFrame) SwingUtilities.getWindowAncestor((JComponent) m.getSource());
				marco.setContentPane(new MaterialesDeJornada(obtenerJornadaSeleccionada()));
				marco.validate();
				cargarTabla(dataModel);
			}
		});
		btnVerMateriales.setBounds(496, 237, 200, 23);
		add(btnVerMateriales);
		
		
		JButton btnNewButton_1 = new JButton("Ver Materiales");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				JFrame marco = 
						(JFrame) SwingUtilities.getWindowAncestor((JComponent) e.getSource());
				marco.setContentPane(new MaterialPanel());
				marco.validate();
			}
		});
		btnNewButton_1.setBounds(37, 350, 200, 23);
		add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("Ver Propuesta");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				JFrame marco = 
						(JFrame) SwingUtilities.getWindowAncestor((JComponent) e.getSource());
				marco.setContentPane(new PropuestaPanel());
				marco.validate();
			}
		});
		btnNewButton_2.setBounds(286,350, 200, 23);
		add(btnNewButton_2);
		
		

		cargarTabla(dataModel);

		
		

	}
	private void cargarTabla(DefaultTableModel dataModel) {
		dataModel.setRowCount(0);
		JornadaDAO eDao = new JornadaDAO();
		jornadas = eDao.traerTodas();
		for (Jornada e : jornadas) {
			Object[] fila = new Object[] {e.getTitulo(), e.getObjetivoPedagogico(), e.getReferenteInstitucional(), e.getObjetivo()};
			dataModel.addRow(fila);
		}
	}

	private Jornada obtenerJornadaSeleccionada() {
		// TODO Mejorar (evitar relacionar el índice de la tabla con el índice del ArrayList)
		int filaSeleccionada = table.getSelectedRow();
		return jornadas.get(filaSeleccionada);
	}
}
