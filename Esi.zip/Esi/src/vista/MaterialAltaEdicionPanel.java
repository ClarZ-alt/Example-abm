package vista;

import javax.swing.JPanel;

import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

import dao.CategoriaDAO;
import dao.MaterialDAO;
import modelo.Jornada;
import modelo.Material;

import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JFrame;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JButton;

public class MaterialAltaEdicionPanel extends JPanel {
	private JTextField txtTitulo;
	private JTextField txtdescripcion;
	private JComboBox<String> comboBox;
	private JTextField txtfuente;
	private JTextField txtenlace;
	private Material material;
	
	public MaterialAltaEdicionPanel() {
		setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Material");
		lblNewLabel.setBounds(114, 11, 46, 14);
		add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("titulo");
		lblNewLabel_1.setBounds(31, 48, 46, 14);
		add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("categoria");
		lblNewLabel_2.setBounds(31, 80, 46, 14);
		add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("descripcion");
		lblNewLabel_3.setBounds(31, 111, 73, 14);
		add(lblNewLabel_3);
		
		JLabel lblNewLabel_4 = new JLabel("fuente");
		lblNewLabel_4.setBounds(31, 142, 46, 14);
		add(lblNewLabel_4);
		
		JLabel lblNewLabel_5 = new JLabel("enlace");
		lblNewLabel_5.setBounds(31, 173, 46, 14);
		add(lblNewLabel_5);
		
		txtTitulo = new JTextField();
		txtTitulo.setBounds(107, 45, 86, 20);
		add(txtTitulo);
		txtTitulo.setColumns(10);
		
		txtdescripcion = new JTextField();
		txtdescripcion.setBounds(107, 108, 86, 20);
		add(txtdescripcion);
		txtdescripcion.setColumns(10);
		
		txtfuente = new JTextField();
		txtfuente.setBounds(107, 139, 86, 20);
		add(txtfuente);
		txtfuente.setColumns(10);
		
		txtenlace = new JTextField();
		txtenlace.setBounds(107, 170, 86, 20);
		add(txtenlace);
		txtenlace.setColumns(10);
		
		comboBox = new JComboBox<String>();
		comboBox.setBounds(107, 76, 86, 22);
		add(comboBox);
		
		CategoriaDAO cDao = new CategoriaDAO();
		ArrayList<String> categorias = cDao.traerTodas();
		comboBox.addItem("selecione categoria");
		for (String c : categorias) {
			
			comboBox.addItem(c);
		}
		
		JButton btnNewButton = new JButton("guardar");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String titulo = txtTitulo.getText();
				 String descripcion= txtdescripcion.getText();
				 String categoria= comboBox.getSelectedItem().toString();
				 String fuente= txtfuente.getText();
				 String enlace=txtenlace.getText();
				 MaterialDAO mDao = new MaterialDAO();
				 
				 if (esEdicion()) {
						// Es una modificación
						Material nuevo = new Material(titulo, descripcion, categoria,fuente,enlace) {
							
							@Override//MODIFICAR MODIFICAR MODIFICAR MODIFICAR MODIFICAR MODIFICAR MODIFICAR MODIFICAR
							public boolean esPrioritario() {
								// TODO Auto-generated method stub
								return false;
							}
						};
						mDao.modificar(nuevo, material.getTitulo());
					} else {
						// Es un alta
						Material material = new Material(titulo, descripcion, categoria,fuente,enlace) {
							
							@Override//MODIFICAR MODIFICAR MODIFICAR MODIFICAR MODIFICAR MODIFICAR MODIFICAR MODIFICAR
							public boolean esPrioritario() {
								// TODO Auto-generated method stub
								return false;
							}
						};
						mDao.guardar(material);
					}
					JFrame marco = 
							(JFrame) SwingUtilities.getWindowAncestor((JComponent) e.getSource());
					marco.setContentPane(new MaterialPanel());
					marco.validate();
			}
		});
		btnNewButton.setBounds(55, 220, 89, 23);
		add(btnNewButton);}
	
		public MaterialAltaEdicionPanel(Material e) {
			// Ejecuto primero el constructor sin argumentos para que se contruya la pantalla.
			this();
			// Cargo los datos del objeto estudiante en los campos de texto.
			txtTitulo.setText(e.getTitulo());
			txtdescripcion.setText(e.getDescripcion());
			comboBox.setSelectedItem(e.getCategoria());
			txtfuente.setText(e.getFuente());
			txtenlace.setText(e.getEnlace());
			this.material = e;
			
		}
		
		public boolean esEdicion() {
			return this.material != null;
			
		}
	
}