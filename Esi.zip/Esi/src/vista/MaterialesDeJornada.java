package vista;
import java.util.ArrayList;



import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.SwingUtilities;
import javax.swing.JScrollPane;
import javax.swing.table.DefaultTableModel;

import dao.JornadaDAO;
import dao.MaterialDAO;
import dao.PropuestaDAO;

import modelo.Jornada;
import modelo.Material;
import modelo.Propuesta;

import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JFrame;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class MaterialesDeJornada extends JPanel{
	private JTable table;
	
	private ArrayList<Material> materiales;

	/**
	 * Create the panel.
	 * @param m 
	 * @param m 
	 */
	public MaterialesDeJornada(Jornada j) {
		setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(36, 76, 450, 250);
		add(scrollPane);
		
		table = new JTable();
		DefaultTableModel dataModel = new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"Titulo","Descripcion", "Categoria", "Enlace", "Fuente"}
		);
		table.setModel(dataModel);
		scrollPane.setViewportView(table);
		
		
		JButton btnNewButton = new JButton("Volver");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				JFrame marco = 
						(JFrame) SwingUtilities.getWindowAncestor((JComponent) e.getSource());
				marco.setContentPane(new MenuPrincipal());
				marco.validate();
				
			}
		});
		btnNewButton.setBounds(38, 360, 89, 23);
		add(btnNewButton);
		

		cargarTabla(dataModel,j );

		
	}
	public MaterialesDeJornada() {
		// TODO Auto-generated constructor stub
	}
	public String extraerVar(Jornada j) {
		
		MaterialesDeJornada(j);
		return j.getObjetivoPedagogico();
	}
	
	private void MaterialesDeJornada(Jornada j) {
		// TODO Auto-generated method stub
		
	}
	private void cargarTabla(DefaultTableModel dataModel, Jornada j) {
		dataModel.setRowCount(0);
		MaterialDAO mDao = new MaterialDAO();
		materiales = mDao.traerMaterialesPorCategoria(extraerVar(j));
		for (Material m : materiales) {
			Object[] fila = new Object[] {m.getTitulo(),m.getDescripcion(), m.getCategoria(), m.getEnlace(), m.getFuente()};
			dataModel.addRow(fila);
		}
		}
}
