package dao;

import java.sql.Connection;

import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import modelo.Material;

public class MaterialDAO {

	public Connection conectar() {
		String url = "jdbc:mysql://localhost:3306/estructura";
		String usr = "root";
		String pass = "admin";

		Connection c = null;
		try {
			c = DriverManager.getConnection(url, usr, pass);
		} catch (SQLException ex) {
			// TODO Auto-generated catch block
			ex.printStackTrace();
		}
		return c;

	}
	public boolean guardar(Material e) {
		//System.out.println("pdao recibio propuesta");
		int filasAfectadas = 0;
		Connection c = null;
		try {
			c = conectar();
			String sql = "INSERT INTO `estructura`.`material`\r\n"
					+ "(`titulo`,`descripcion`,`categoria`,`fuente`,`enlace`)\r\n"
					+ "VALUES(?,?,?,?,?);";
			
			PreparedStatement pStmt = c.prepareStatement(sql);
			pStmt.setString(1, e.getTitulo());
			pStmt.setString(2, e.getDescripcion());
			pStmt.setString(3, e.getCategoria());
			pStmt.setString(4, e.getFuente());
			pStmt.setString(5, e.getEnlace());

			filasAfectadas = pStmt.executeUpdate();
		} catch (SQLException ex) {
			// TODO Auto-generated catch block
			ex.printStackTrace();
		} finally {
			try {
				if (c != null) {
					c.close();
				}
			} catch (SQLException ex) {
				// TODO Auto-generated catch block
				ex.printStackTrace();
			}
		}
		return filasAfectadas != 0;
	}
	public boolean modificar( Material e, String tituloAnterior) {

		int filasAfectadas = 0;
		Connection c = null;
		try {
			c = conectar();
			String sql = "UPDATE `material` SET `titulo` = ?,`descripcion` = ?,`categoria`= ?,`fuente` = ?,`enlace` = ? WHERE `titulo` = ?;";
			PreparedStatement pStmt = c.prepareStatement(sql);
			pStmt.setString(1, e.getTitulo());
			pStmt.setString(2, e.getDescripcion());
			pStmt.setString(3, e.getCategoria());
			pStmt.setString(4, e.getFuente());
			pStmt.setString(5, e.getEnlace());
			//pStmt.setString(6, tituloAnterior);
			filasAfectadas = pStmt.executeUpdate();
		} catch (SQLException ex) {
			// TODO Auto-generated catch block
			ex.printStackTrace();
		} finally {
			try {
				if (c != null) {
					c.close();
				}
			} catch (SQLException ex) {
				// TODO Auto-generated catch block
				ex.printStackTrace();
			}
		}
		return filasAfectadas != 0;
	}

	public boolean eliminar(String titulo) {

		int filasAfectadas = 0;
		Connection c = null;
		try {
			c = conectar();
			String sql = "DELETE FROM `material` WHERE titulo = ?;";
			PreparedStatement pStmt = c.prepareStatement(sql);
			pStmt.setString(1, titulo);

			filasAfectadas = pStmt.executeUpdate();
		} catch (SQLException ex) {
			// TODO Auto-generated catch block
			ex.printStackTrace();
		} finally {
			try {
				if (c != null) {
					c.close();
				}
			} catch (SQLException ex) {
				// TODO Auto-generated catch block
				ex.printStackTrace();
			}
		}
		return filasAfectadas != 0;
	}
	public ArrayList<Material> traerTodas() {
		ArrayList<Material> materiales = new ArrayList<Material>();
		Connection c = null;
		try {
			c = conectar();
			String sql = "SELECT `titulo`,`descripcion`,`categoria`,`fuente`,`enlace`  FROM `material`";
			Statement stmt = c.createStatement();
			ResultSet rs = stmt.executeQuery(sql);

			while (rs.next()) {

				String titulo = rs.getString("titulo");
				String descripcion = rs.getString("descripcion");
				String categoria = rs.getString("categoria");
				String fuente = rs.getString("fuente");
				String enlace = rs.getString("enlace");
				
				materiales.add(new Material(titulo, descripcion, categoria, fuente, enlace){
					
					@Override//MODIFICAR MODIFICAR MODIFICAR MODIFICAR MODIFICAR MODIFICAR MODIFICAR MODIFICAR
					public boolean esPrioritario() {
						// TODO Auto-generated method stub
						return false;
					}
				});
			}

		} catch (SQLException ex) {
			// TODO Auto-generated catch block
			ex.printStackTrace();
		} finally {
			try {
				if (c != null) {
					c.close();
				}
			} catch (SQLException ex) {
				// TODO Auto-generated catch block
				ex.printStackTrace();
			}
		}
		
		return materiales;

	}//:)
	public ArrayList<Material> traerMaterialesPorCategoria(String catego) {
		
		ArrayList<Material> materiales = new ArrayList<Material>();
		Connection c = null;
		try {
			c = conectar();
			String sql = "SELECT *  FROM material WHERE categoria LIKE'"+catego+"' ";
			Statement stmt = c.createStatement();
			ResultSet rs = stmt.executeQuery(sql);

			while (rs.next()) {

				String titulo = rs.getString("titulo");
				String descripcion = rs.getString("descripcion");
				String categoria = rs.getString("categoria");
				String fuente = rs.getString("fuente");
				String enlace = rs.getString("enlace");
				
				//materiales.add(nnew M)
				materiales.add(new Material(titulo, descripcion, categoria, fuente, enlace){
					
					@Override//MODIFICAR MODIFICAR MODIFICAR MODIFICAR MODIFICAR MODIFICAR MODIFICAR MODIFICAR
					public boolean esPrioritario() {
						// TODO Auto-generated method stub
						return false;
					}
				});
			}

		} catch (SQLException ex) {
			// TODO Auto-generated catch block
			ex.printStackTrace();
		} finally {
			try {
				if (c != null) {
					c.close();
				}
			} catch (SQLException ex) {
				// TODO Auto-generated catch block
				ex.printStackTrace();
			}
		}
		
		return materiales;}
}