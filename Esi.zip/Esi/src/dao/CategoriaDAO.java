package dao;

import java.sql.Connection;

import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import javax.swing.JComboBox;

 
public class CategoriaDAO {
	
	public Connection conectar() {
		String url= "jdbc:mysql://localhost:3306/estructura";
		String usr = "root";
		String pass = "admin";
		
		Connection c = null;
		try {
			c = DriverManager.getConnection(url, usr, pass);
		} catch (SQLException ex) {
			// TODO Auto-generated catch block
			ex.printStackTrace();
		}
		return c;

	}
	public ArrayList<String> traerTodas() {
		ArrayList<String> categorias = new ArrayList<String>();
		Connection c= null;
		try {
			String sql = "SELECT `nombre` from `estructura`.`categoria`;";
			c = conectar();			
			Statement pStmt = c.createStatement();
			ResultSet rs = pStmt.executeQuery(sql);
			while(rs.next()) {
				rs.getString("nombre");
				categorias.add(rs.getString("nombre"));
			}
		} catch (SQLException ex) {
			// TODO Auto-generated catch block
			ex.printStackTrace();
		} finally {
			try {
				if (c != null) {
					c.close();
				}
			} catch (SQLException ex) {
				// TODO Auto-generated catch block
				ex.printStackTrace();
			}
		}
		
		
		return categorias;
	}
	

}
