package dao;

import java.sql.Connection;

 
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import modelo.Jornada;

public class JornadaDAO {
	
	public Connection conectar() {
		String url= "jdbc:mysql://localhost:3306/estructura";
		String usr = "root";
		String pass = "admin";
		
		Connection c = null;
		try {
			c = DriverManager.getConnection(url, usr, pass);
		} catch (SQLException ex) {
			// TODO Auto-generated catch block
			ex.printStackTrace();
		}
		return c;

	}
	public boolean guardar(Jornada e) {

		int filasAfectadas = 0;
		Connection c = null;
		try {
			c = conectar();
			String sql = "INSERT INTO `estructura`.`jornada`(`titulo`,`objetivoPedagogico`,`referenteInstitucional`,`objetivo`)VALUES(?, ?, ?, ?)";
//falta completar
			PreparedStatement pStmt = c.prepareStatement(sql);

			pStmt.setString(1, e.getTitulo());
			pStmt.setString(2, e.getObjetivoPedagogico());
			pStmt.setString(3, e.getReferenteInstitucional());
			pStmt.setString(4, e.getObjetivo());
			
			filasAfectadas = pStmt.executeUpdate();
		} catch (SQLException ex) {
			// TODO Auto-generated catch block
			ex.printStackTrace();
		} finally {
			try {
				if (c != null) {
					c.close();
				}
			} catch (SQLException ex) {
				// TODO Auto-generated catch block
				ex.printStackTrace();
			}
		}
		return filasAfectadas != 0;
	}
	public boolean modificar(Jornada e, String titulo) {

		int filasAfectadas = 0;
		Connection c = null;
		try {
			c = conectar();
			String sql = "UPDATE `jornada` SET `titulo` = ?, `objetivoPedagogico` = ?, `referenteInstitucional` = ?,`objetivo` = ? WHERE `titulo` = ?;";
			PreparedStatement pStmt = c.prepareStatement(sql);
			pStmt.setString(1, e.getTitulo());
			pStmt.setString(2, e.getObjetivoPedagogico());
			pStmt.setString(3, e.getReferenteInstitucional());
			pStmt.setString(4, e.getObjetivo());
			pStmt.setString(5, titulo);

			filasAfectadas = pStmt.executeUpdate();
		} catch (SQLException ex) {
			// TODO Auto-generated catch block
			ex.printStackTrace();
		} finally {
			try {
				if (c != null) {
					c.close();
				}
			} catch (SQLException ex) {
				// TODO Auto-generated catch block
				ex.printStackTrace();
			}
		}
		return filasAfectadas != 0;
	}

	public boolean eliminar(String titulo) {

		int filasAfectadas = 0;
		Connection c = null;
		try {
			c = conectar();
			String sql = "DELETE FROM `jornada` WHERE titulo = ?; ";
					//+ "DELETE material  FROM material JOIN jornada ON material.categoria =jornada.objetivoPedagogico WHERE jornada.objetivoPedagogico='"+catego+"' ;";
			PreparedStatement pStmt = c.prepareStatement(sql);
			pStmt.setString(1, titulo);
			//pStmt.setString(2, catego);

			filasAfectadas = pStmt.executeUpdate();
		} catch (SQLException ex) {
			// TODO Auto-generated catch block
			ex.printStackTrace();
		} finally {
			try {
				if (c != null) {
					c.close();
				}
			} catch (SQLException ex) {
				// TODO Auto-generated catch block
				ex.printStackTrace();
			}
		}
		return filasAfectadas != 0;
	}
	public ArrayList<Jornada> traerTodas() {
		ArrayList<Jornada> jornadas = new ArrayList<Jornada>();
		Connection c = null;
		try {
			c = conectar();
			String sql = "SELECT `titulo`, `objetivoPedagogico`, `referenteInstitucional`, `objetivo` FROM `jornada`";
			Statement stmt = c.createStatement();

			ResultSet rs = stmt.executeQuery(sql);

			while (rs.next()) {
				
				String titulo = rs.getString("titulo");
				String objetivoPedagogico = rs.getString("objetivoPedagogico");
				String referenteInstitucional = rs.getString("referenteInstitucional");
				String objetivo= rs.getString("objetivo");
				
				jornadas.add(new Jornada(titulo, objetivoPedagogico, referenteInstitucional,objetivo));
			}

		} catch (SQLException ex) {
			// TODO Auto-generated catch block
			ex.printStackTrace();
		} finally {
			try {
				if (c != null) {
					c.close();
				}
			} catch (SQLException ex) {
				// TODO Auto-generated catch block
				ex.printStackTrace();
			}
		}
		return jornadas;

	}


}