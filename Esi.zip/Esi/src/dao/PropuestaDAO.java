package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import modelo.Material;
import modelo.Propuesta;

public class PropuestaDAO {

	public Connection conectar() {
		String url = "jdbc:mysql://localhost:3306/estructura";
		String usr = "root";
		String pass = "admin";

		Connection c = null;
		try {
			c = DriverManager.getConnection(url, usr, pass);
		} catch (SQLException ex) {
			// TODO Auto-generated catch block
			ex.printStackTrace();
		}
		return c;

	}

	public boolean guardar(Propuesta e) {
		System.out.println("pdao recibio propuesta");
		int filasAfectadas = 0;
		Connection c = null;
		try {
			c = conectar();
			String sql = "INSERT INTO `estructura`.`propuesta`\r\n"
					+ "(`titulo`,`origen`,`categoria`,`autor`,`fecha`,`descripcion`,`motivacion`,`estado`,`motivo`)\r\n"
					+ "VALUES(?,?,?,?,?,?,?,?,?);";
			
			PreparedStatement pStmt = c.prepareStatement(sql);
			pStmt.setString(1, e.getTitulo());
			pStmt.setString(2, e.getOrigen());
			pStmt.setString(3, e.getCategoria());
			pStmt.setString(4, e.getAutor());
			pStmt.setInt(5, e.getFecha());
			pStmt.setString(6, e.getDescripcion());
			pStmt.setString(7, e.getMotivacion());
			pStmt.setString(8, e.getEstado());
			pStmt.setString(9, e.getMotivo());

			filasAfectadas = pStmt.executeUpdate();
		} catch (SQLException ex) {
			// TODO Auto-generated catch block
			ex.printStackTrace();
		} finally {
			try {
				if (c != null) {
					c.close();
				}
			} catch (SQLException ex) {
				// TODO Auto-generated catch block
				ex.printStackTrace();
			}
		}
		return filasAfectadas != 0;
	}

	public boolean modificar(String tituloAnterior, Propuesta e) {

		int filasAfectadas = 0;
		Connection c = null;
		try {
			c = conectar();
			String sql = "UPDATE `propuesta` SET `titulo` = ?,`origen` = ?,`categoria`= ?,`autor` = ?,`fecha` = ?,`descripcion` = ?,`motivacion` = ?, `estado` = ?, `motivo` = ? WHERE `titulo` = ?;";
			PreparedStatement pStmt = c.prepareStatement(sql);
			pStmt.setString(1, e.getTitulo());
			pStmt.setString(2, e.getOrigen());
			pStmt.setString(3, e.getCategoria());
			pStmt.setString(4, e.getAutor());
			pStmt.setInt(5, e.getFecha());
			pStmt.setString(6, e.getDescripcion());
			pStmt.setString(7, e.getMotivacion());
			pStmt.setString(8, e.getEstado());
			pStmt.setString(9, e.getMotivo());
			pStmt.setString(10, tituloAnterior);
			
			filasAfectadas = pStmt.executeUpdate();
		} catch (SQLException ex) {
			// TODO Auto-generated catch block
			ex.printStackTrace();
		} finally {
			try {
				if (c != null) {
					c.close();
				}
			} catch (SQLException ex) {
				// TODO Auto-generated catch block
				ex.printStackTrace();
			}
		}
		return filasAfectadas != 0;

	}

	public boolean eliminar(String titulo) {

		int filasAfectadas = 0;
		Connection c = null;
		try {
			c = conectar();
			String sql = "DELETE FROM `propuesta` WHERE titulo = ?;";
			PreparedStatement pStmt = c.prepareStatement(sql);
			pStmt.setString(1, titulo);

			filasAfectadas = pStmt.executeUpdate();
		} catch (SQLException ex) {
			// TODO Auto-generated catch block
			ex.printStackTrace();
		} finally {
			try {
				if (c != null) {
					c.close();
				}
			} catch (SQLException ex) {
				// TODO Auto-generated catch block
				ex.printStackTrace();
			}
		}
		return filasAfectadas != 0;

	}

	public ArrayList<Propuesta> traerTodes() {
		ArrayList<Propuesta> propuestas = new ArrayList<Propuesta>();
		Connection c = null;
		try {
			c = conectar();
			String sql = "SELECT `titulo`,`origen`,`categoria`,`autor`,`fecha`,`descripcion`,`motivacion`,`estado`,`motivo`  FROM `propuesta`";
			Statement stmt = c.createStatement();

			ResultSet rs = stmt.executeQuery(sql);

			while (rs.next()) {

				String origen = rs.getString("origen");
				String autor = rs.getString("autor");
				int fecha = rs.getInt("fecha");
				String titulo = rs.getString("titulo");
				String descripcion = rs.getString("descripcion");
				String motivacion = rs.getString("motivacion");
				String categoria = rs.getString("categoria");
				String estado = rs.getString("estado");
				propuestas.add(new Propuesta(origen, autor, fecha, titulo, descripcion, motivacion, categoria, estado));
			}

		} catch (SQLException ex) {
			// TODO Auto-generated catch block
			ex.printStackTrace();
		} finally {
			try {
				if (c != null) {
					c.close();
				}
			} catch (SQLException ex) {
				// TODO Auto-generated catch block
				ex.printStackTrace();
			}
		}
		return propuestas;

	}
	public ArrayList<Propuesta> traerPendientes() {
		ArrayList<Propuesta> propuestas = new ArrayList<Propuesta>();
		Connection c = null;
		try {
			c = conectar();
			String sql = "SELECT `titulo`,`origen`,`categoria`,`autor`,`fecha`,`descripcion`,`motivacion`,`estado`,`motivo`  FROM `propuesta`"
					+ "WHERE estado='pendiente' ;";
			Statement stmt = c.createStatement();

			ResultSet rs = stmt.executeQuery(sql);

			while (rs.next()) {

				String origen = rs.getString("origen");
				String autor = rs.getString("autor");
				int fecha = rs.getInt("fecha");
				String titulo = rs.getString("titulo");
				String descripcion = rs.getString("descripcion");
				String motivacion = rs.getString("motivacion");
				String categoria = rs.getString("categoria");
				String estado = rs.getString("estado");
				propuestas.add(new Propuesta(origen, autor, fecha, titulo, descripcion, motivacion, categoria, estado));
			}

		} catch (SQLException ex) {
			// TODO Auto-generated catch block
			ex.printStackTrace();
		} finally {
			try {
				if (c != null) {
					c.close();
				}
			} catch (SQLException ex) {
				// TODO Auto-generated catch block
				ex.printStackTrace();
			}
		}
		return propuestas;

	}
	
	public boolean modificarEstado(String estado,String titulo) {
		// TODO Auto-generated method stub

			int filasAfectadas = 0;
			Connection c = null;
			try {
				c = conectar();
				String sql = "UPDATE `propuesta` SET  `estado` = ? WHERE `titulo`= ? ;";
				PreparedStatement pStmt = c.prepareStatement(sql);
				pStmt.setString(1, estado);
				pStmt.setString(2, titulo);
				
				filasAfectadas = pStmt.executeUpdate();
			} catch (SQLException ex) {
				// TODO Auto-generated catch block
				ex.printStackTrace();
			} finally {
				try {
					if (c != null) {
						c.close();
					}
				} catch (SQLException ex) {
					// TODO Auto-generated catch block
					ex.printStackTrace();
				}
			}
			return filasAfectadas != 0;
	}

	public ArrayList<Propuesta> traerPropuestasPorCategoria(String catego) {
		// TODO Auto-generated method stubpublic ArrayList<Material> traerMaterialesPorCategoria(String catego) {
		
		ArrayList<Propuesta> propuestas = new ArrayList<Propuesta>();
		Connection c = null;
		try {
			c = conectar();
			String sql = "SELECT *  FROM propuesta WHERE estado='Aprobado' AND categoria LIKE'"+catego+"' ";
			Statement stmt = c.createStatement();
			ResultSet rs = stmt.executeQuery(sql);

			while (rs.next()) {
				String origen = rs.getString("origen");
			String autor = rs.getString("autor");
			int fecha = rs.getInt("fecha");
			String titulo = rs.getString("titulo");
			String descripcion = rs.getString("descripcion");
			String motivacion = rs.getString("motivacion");
			String categoria = rs.getString("categoria");
			String estado = rs.getString("estado");
			propuestas.add(new Propuesta(origen, autor, fecha, titulo, descripcion, motivacion, categoria, estado));
			}

		} catch (SQLException ex) {
			// TODO Auto-generated catch block
			ex.printStackTrace();
		} finally {
			try {
				if (c != null) {
					c.close();
				}
			} catch (SQLException ex) {
				// TODO Auto-generated catch block
				ex.printStackTrace();
			}
		}
		
		return propuestas;}
	}
	
	
				//String sql =  "SELECT *  FROM propuesta WHERE categoria LIKE'"+string+"' AND categoria LIKE 'Aprobado' ; ";
				

	
